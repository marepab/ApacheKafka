package com.kaf.apachekafka.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.kaf.apachekafka.storage.MessageEntity;
import com.kaf.apachekafka.storage.MessageRepository;


@Component
public class KafkaConsumer {
	private static final Logger log = LoggerFactory.getLogger(KafkaConsumer.class);
	
	@Autowired
	private MessageRepository messageRepository;
	
	@KafkaListener(topics = "${kafka.topic}", containerFactory = "messageKafkaListenerContainerFactory")
    public void messageListener(MessageEntity messageEntity) {
		log.info("Recieved message: " + messageEntity);
		
		// integrate analytics here
		
		messageRepository.saveAndFlush(messageEntity);
		
		log.info(messageRepository.getByCustomerId(messageEntity.getCustomerId()).toString());
		log.info("message saved successfully to database");
		
    }
}
